#ifndef __MDFN_TIME64_H
#define __MDFN_TIME64_H

int64 MBL_Time64(void);
void MBL_Sleep64(int64 microseconds);

#endif
