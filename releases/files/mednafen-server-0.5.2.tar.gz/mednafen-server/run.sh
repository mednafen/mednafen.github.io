#!/bin/sh

./mednafen-server standard.conf >serverlog 2>serverlog2
